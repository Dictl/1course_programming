#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidget>
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onMainWindowClose();
    void on_pushButton_Exit_clicked();

    void on_pushButton_Search_clicked();

    void on_pushButtonAll_clicked();

    void on_lineMaths_textChanged(const QString &arg1);

    void on_lineFiziks_textChanged(const QString &arg1);

    void on_lineIInformatic_textChanged(const QString &arg1);

    void on_lineRusLang_textChanged(const QString &arg1);

    void on_listWidget_itemClicked(QListWidgetItem *item);

    void on_pushButton_Delete_clicked();

    void on_pushButton_Save_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_addPhoto_clicked();

    void on_pushButton_Add_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
