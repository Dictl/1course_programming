#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include "RapidXML\rapidxml.hpp"
#include "RapidXML\rapidxml_print.hpp"
#include "QMessageBox"
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <string>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QIntValidator>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <algorithm>
#include <QFileDialog>
#include <QDir>

using namespace std;
int clickedItem = 0;
struct human {
    QString icon;
    QString name;
    QString surname;
    QString patronomic;
    QString birth;
    bool education;
    int maths;
    int physics;
    int informatics;
    int russian;

};
struct myList{
    human h;
    myList *next;
    myList *prev;
};
QString icoTemp;

myList *createList(unsigned lenght){
    myList *curr = 0, *nextTmp = nullptr;
    for (unsigned i=1; i<=lenght; i++){
        curr = new myList;
        curr->h.icon = "";
        curr->h.name = "";
        curr->h.surname = "";
        curr->h.patronomic = "";
        curr->h.birth = "";
        curr->h.education = 0;
        curr->h.maths = 0;
        curr->h.physics = 0;
        curr->h.informatics = 0;
        curr->h.russian = 0;
        curr->next = nextTmp;
        if (nextTmp)
            nextTmp -> prev = curr;
        nextTmp = curr;
    }
    curr->prev = nullptr;
    return curr;
}
myList *getItem(myList *beg, unsigned index){
    while (beg && (index--))
        beg = beg->next;
    return beg;
}

unsigned getLeght(myList *beg){
    unsigned leght = 0;
    while (beg){
        ++leght;
        beg = beg->next;
    }
    return leght;
}
void delItem(myList *&beg, unsigned index){
    if (index >= getLeght(beg))
        return;
    myList *item;
    if (!index){
        item = beg->next;
        delete beg;
        beg = item;
        beg->prev = 0;
        return;
    }
    if (index == getLeght(beg) - 1){
        item = getItem(beg, index - 1);
        myList *delit = item->next;
        item->next = 0;
        delete delit;
        return;
    }
    item = getItem(beg, index - 1);
    myList *ditem = item->next;
    item->next = ditem->next;
    ditem->next->prev = item;
    delete ditem;
}
myList* addItem(myList*& beg, human newData) {
    myList* item = new myList;
    item->h = newData;
    item->next = nullptr;

    if (!beg) {
        item->prev = nullptr;
        beg = item;
        return item;
    }

    myList* last = beg;
    while (last->next) {
        last = last->next;
    }

    last->next = item;
    item->prev = last;

    return item;
}

bool dataType = 0;
myList* persons,*sortedPersons;
bool compareByTotalScore(const human& a, const human& b) {
    int sumA = a.maths + a.russian ;
    int sumB = b.maths + b.russian ;
    if(a.informatics>a.physics){
        sumA+=a.informatics;
    }else{
        sumA+=a.physics;
    }
    if(b.informatics>b.physics){
        sumA+=b.informatics;
    }else{
        sumA+=b.physics;
    }
    // Sort descending for highest total score first
    return sumA > sumB;
}

myList listElement(myList *beg, unsigned index){
    while (beg && (index--))
        beg = beg->next;
    return *beg;
}

void createXML(myList* persons, const std::string& filename) {


    // Создаем документ
    rapidxml::xml_document<> doc;

    // Создаем корневой элемент <parts>
    rapidxml::xml_node<> *root = doc.allocate_node(rapidxml::node_type::node_element, "parts");
    doc.append_node(root);

    // Проходимся по каждому элементу списка
    for (myList* i = persons;i;i = i->next){
        // Создаем элемент <a1>
        rapidxml::xml_node<> *a1 = doc.allocate_node(rapidxml::node_type::node_element, "a1");
        root->append_node(a1);

        // Создаем и добавляем элементы для каждого поля структуры human
        a1->append_node(doc.allocate_node(rapidxml::node_type::node_element, "icon", doc.allocate_string(i->h.icon.toStdString().c_str())));
        a1->append_node(doc.allocate_node(rapidxml::node_type::node_element, "name", doc.allocate_string(i->h.name.toStdString().c_str())));
        a1->append_node(doc.allocate_node(rapidxml::node_type::node_element, "surname", doc.allocate_string(i->h.surname.toStdString().c_str())));
        a1->append_node(doc.allocate_node(rapidxml::node_type::node_element, "patronymic", doc.allocate_string(i->h.patronomic.toStdString().c_str())));
        a1->append_node(doc.allocate_node(rapidxml::node_type::node_element, "birth", doc.allocate_string(i->h.birth.toStdString().c_str())));

        // Преобразуем education в строку "0" или "1"
        a1->append_node(doc.allocate_node(rapidxml::node_type::node_element, "education", doc.allocate_string(i->h.education ? "1" : "0")));

        // Создаем элемент <results>
        rapidxml::xml_node<> *results = doc.allocate_node(rapidxml::node_type::node_element, "results");
        a1->append_node(results);

        // Добавляем элементы для результатов
        results->append_node(doc.allocate_node(rapidxml::node_type::node_element, "maths", doc.allocate_string(std::to_string(i->h.maths).c_str())));
        results->append_node(doc.allocate_node(rapidxml::node_type::node_element, "physics", doc.allocate_string(std::to_string(i->h.physics).c_str())));
        results->append_node(doc.allocate_node(rapidxml::node_type::node_element, "informatics", doc.allocate_string(std::to_string(i->h.informatics).c_str())));
        results->append_node(doc.allocate_node(rapidxml::node_type::node_element, "russian", doc.allocate_string(std::to_string(i->h.russian).c_str())));
    }

    // Сохранение в файл
    std::ofstream file_stored(filename);
    string s;
    rapidxml::print(std::back_inserter(s),doc,0);
    file_stored<<s;
    file_stored.close();
}
string parseDevicesFromXML(const string& xmlData) {
    char* xmlChar = const_cast<char *>(xmlData.c_str());
    string state = "";
    rapidxml::xml_document<> doc;//создать пустой
    doc.parse<0>(xmlChar);
    rapidxml::xml_node<>* rootNode = doc.first_node();
    QString rootName = rootNode->name();
    int nomerl=0;
    if (rootName == "parts"){
        for (rapidxml::xml_node<>* deviceNode = rootNode->first_node(); deviceNode; deviceNode = deviceNode->next_sibling()){
            nomerl++;
            qDebug()<<nomerl<<"\n";
        }
        persons = createList(nomerl);
        myList* pers = persons;
        for (rapidxml::xml_node<>* deviceNode = rootNode->first_node(); deviceNode; deviceNode = deviceNode->next_sibling()) {
            pers->h.name = (QString)deviceNode->first_node("name")->value();
            pers->h.icon = (QString)deviceNode->first_node("icon")->value();
            pers->h.surname = (QString)deviceNode->first_node("surname")->value();
            pers->h.patronomic = (QString)deviceNode->first_node("patronymic")->value();
            pers->h.birth = (QString)deviceNode->first_node("birth")->value();
            pers->h.education = (bool)deviceNode->first_node("education")->value();
            rapidxml::xml_node<>* resNode = deviceNode->first_node("results");
            pers->h.maths = stoi((string)resNode->first_node("maths")->value());
            pers->h.physics = stoi((string)resNode->first_node("physics")->value());
            pers->h.informatics = stoi((string)resNode->first_node("informatics")->value());
            pers->h.russian = stoi((string)resNode->first_node("russian")->value());
            pers = pers->next;
        }
    }else{
        cout<<"root node \"parts\" not found";
        state = "root node \"parts\" not found";
    }
    return state;
}

string parseDevicesFromXMLFile(const std::string& fileName) {
    std::ifstream file(fileName);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file: " << fileName << std::endl;
        return {};  // Return empty vector on error
    }

    std::stringstream xmlDataStream;
    xmlDataStream << file.rdbuf();//передача всего файла
    file.close();

    std::string xmlData = xmlDataStream.str();
    return parseDevicesFromXML(xmlData);  // Reuse the existing parseDevicesFromXML function
}
void printListALL(QListWidget* list, myList* h){
    list->clear();
    int i = 0;
    for (myList* j= h;j; j=j->next) {
        i++;
        QListWidgetItem* listItem = new QListWidgetItem;
        stringstream ss;
        ss<< i<<". "<< j->h.name.toStdString()<<" "<<j->h.surname.toStdString()<<" "<<j->h.patronomic.toStdString();
        string s = ss.str();
        listItem->setText(QString::fromStdString(s));
        list->addItem(listItem);
    }

}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    parseDevicesFromXMLFile(QFileDialog::getOpenFileName(this, "Выберите файл", "", "*.xml").toStdString());
    printListALL(ui->listWidget,persons);
    QRegularExpression rx("[А-Яа-я.,() IV`ёЁ\x002D]{1,30}");
    QRegularExpressionValidator *validator = new QRegularExpressionValidator(rx,0);
    QIntValidator *les = new QIntValidator(0,100,0);
    ui->DateBirth->setMaximumDate(QDate(2015, 1, 1));
    ui->lineFiziks->setValidator(les);
    ui->lineMaths->setValidator(les);
    ui->lineRusLang->setValidator(les);
    ui->lineIInformatic->setValidator(les);
    ui->lineSurname->setValidator(validator);
    ui->lineName->setValidator(validator);
    ui->linePatronomic->setValidator(validator);
}

MainWindow::~MainWindow()
{
    createXML(persons,"../basadan/ss.xml");
    delete ui;
}

QString getText(MainWindow* rrr) {
    QString str;
    str = QFileDialog::getOpenFileName(rrr, "Выберите изображение", "", "Images (*.png *.jpg *.webp");
    return str;
}
void MainWindow::on_pushButton_Exit_clicked()
{
    QMessageBox::StandardButton reply = QMessageBox::question(this, "Выход", "Вы уверены что хотите выйти?", QMessageBox::Yes | QMessageBox::No);
    if(reply==QMessageBox::Yes)
    {
        createXML(persons,"../basadan/ss.xml");
        QApplication::quit();
    }
    else {qDebug()<<"кнопка нет была нажата";}
}


void MainWindow::on_pushButton_Search_clicked()//поиск
{
    QString search = ui->lineSearch->text();
    if(search != ""){
        for(int i = ui->listWidget->count()-1;i>=0;i--){
            string str = ui->listWidget->item(i)->text().toStdString();
            if(str.find(search.toStdString()) == std::string::npos ){
                delete ui->listWidget->item(i);
            }
        }

    }
}




void MainWindow::on_pushButtonAll_clicked()
{
    myList* i =persons;
    printListALL(ui->listWidget,i);
    dataType =0;
}


void MainWindow::on_lineMaths_textChanged(const QString &arg1)
{
    Q_UNUSED(&arg1);
    int t = ui->lineMaths->text().toInt();
    if(t>100){
        ui->lineMaths->setText("100");
    }
}


void MainWindow::on_lineFiziks_textChanged(const QString &arg1)
{
    Q_UNUSED(&arg1);
    int t = ui->lineFiziks->text().toInt();
    if(t>100){
        ui->lineFiziks->setText("100");
    }
}


void MainWindow::on_lineIInformatic_textChanged(const QString &arg1)
{
    Q_UNUSED(&arg1);
    int t = ui->lineIInformatic->text().toInt();
    if(t>100){
        ui->lineIInformatic->setText("100");
    }
}


void MainWindow::on_lineRusLang_textChanged(const QString &arg1)
{
    Q_UNUSED(&arg1);
    int t = ui->lineRusLang->text().toInt();
    if(t>100){
        ui->lineRusLang->setText("100");
    }
}
void MainWindow::on_pushButton_2_clicked()
{
    QMessageBox::information(this, "Редактирование запрещено", "В данной вкладке редактирование/удаление/добавление запрещенно", QMessageBox::Ok);
    dataType =1;
    int counter = 0;
    if(sortedPersons){
        while(getLeght(sortedPersons)>1){
            delItem(sortedPersons,1);
        }
        sortedPersons->h.maths = 0;sortedPersons->h.physics = 0;sortedPersons->h.russian=0;sortedPersons->h.informatics=0;
    }else{
        sortedPersons = createList(1);
        sortedPersons->h.maths = 0;sortedPersons->h.physics = 0;sortedPersons->h.russian=0;sortedPersons->h.informatics=0;
    }


    for (myList* j= persons; j; j=j->next) {
        addItem(sortedPersons,j->h);

    }
    bool noDel = false;
    while(!noDel){
        int i = 0;
    for (myList* it= sortedPersons; it; it=it->next) {
            noDel = true;
        int sumA = it->h.maths + it->h.russian ;
        if(it->h.informatics>it->h.physics){
            sumA+=it->h.informatics;
        }else{
            sumA+=it->h.physics;
        }
        if(sumA<250){
            delItem(sortedPersons,i);
            noDel = false;
            break;
                // Move the iterator one step towards the beginning

        }
        i++;
    }};
    printListALL(ui->listWidget,sortedPersons);
}


void MainWindow::on_listWidget_itemClicked(QListWidgetItem *item)
{
    QString humanvb = item->text();

    string str(humanvb.toStdString());
    int t = stoi(str);
    t--;
    human use;
    clickedItem = t;
    if(dataType){
        use = listElement(sortedPersons,t).h;
    }else{
        use = listElement(persons,t).h;
    }
    icoTemp = use.icon;
    ui->lineName->setText(use.name);
    ui->lineSurname->setText(use.surname);
    ui->linePatronomic->setText(use.patronomic);
    ui->lineMaths->setText(QString::fromStdString( to_string(use.maths)));
    ui->lineFiziks->setText(QString::fromStdString( to_string(use.physics)));
    ui->lineRusLang->setText(QString::fromStdString( to_string(use.russian)));
    ui->lineIInformatic->setText(QString::fromStdString( to_string(use.informatics)));
    if(use.education){
        ui->radioButton->click();
    }else{
        ui->radioButton_2->click();
    }
    QDate date = QDate::fromString(use.birth,"dd.MM.yyyy");
    ui->DateBirth->setDate(date);
    QPixmap image(use.icon);
    ui->pushButton_addPhoto->setIcon(image);
}


void MainWindow::on_pushButton_Delete_clicked()
{
    if(dataType){
        QMessageBox::information(this, "Невозможное действие", "Это можно сделать только во вкладке \"все\"", QMessageBox::Ok);

    }else{

        delItem(persons, clickedItem);
        printListALL(ui->listWidget,persons);
    }
}


void MainWindow::on_pushButton_Save_clicked()
{
    if(dataType){
        QMessageBox::information(this, "Невозможное действие", "Это можно сделать только во вкладке \"все\"", QMessageBox::Ok);

    }else{
        myList* use = getItem(persons,clickedItem);

    // Erase the item at position 5
    use->h.surname = ui->lineSurname->text();
    use->h.name = ui->lineName->text();
    use->h.patronomic = ui->linePatronomic->text();
    use->h.physics = ui->lineFiziks->text().toInt();
    use->h.maths= ui->lineMaths->text().toInt();
    use->h.informatics= ui->lineIInformatic->text().toInt();
    use->h.russian= ui->lineRusLang->text().toInt();
    use->h.birth = ui->DateBirth->text();
    use->h.icon = icoTemp;

    if(ui->radioButton->isEnabled()){
        use->h.education = 1;
    }else{
        use->h.education = 0;
    }
    printListALL(ui->listWidget,persons);}
}





void MainWindow::on_pushButton_addPhoto_clicked()
{
    if(dataType){
        QMessageBox::information(this, "Невозможное действие", "Это можно сделать только во вкладке \"все\"", QMessageBox::Ok);

    }else{
    icoTemp = getText(this);}


}


void MainWindow::on_pushButton_Add_clicked()
{
    if(dataType){
        QMessageBox::information(this, "Невозможное действие", "Это можно сделать только во вкладке \"все\"", QMessageBox::Ok);

    }else{
        human use;
        myList* it = getItem(persons,clickedItem);
        use.icon = icoTemp;
        use.surname = ui->lineSurname->text();
        use.name = ui->lineName->text();
        use.patronomic = ui->linePatronomic->text();
        use.physics = ui->lineFiziks->text().toInt();
        use.maths= ui->lineMaths->text().toInt();
        use.informatics= ui->lineIInformatic->text().toInt();
        use.russian= ui->lineRusLang->text().toInt();
        use.birth = ui->DateBirth->text();
        if(ui->radioButton->isEnabled()){
            use.education = 1;
        }else{
            use.education = 0;
        }

        addItem(persons,use);
    printListALL(ui->listWidget,persons);
    }
}

